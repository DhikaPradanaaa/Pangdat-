# Olist OLTP - hasil peningkatan kualitas data

Dataset ini diproses berdasarkan karakteristik kualitas data pada Bab 10.1.2 buku *Data Warehouse: Teori dan Praktek*.

## Struktur keluaran

- `raw/`: sembilan CSV sumber yang diekstrak tanpa perubahan.
- `clean/`: sembilan tabel hasil normalisasi dan validasi.
- `quarantine/`: salinan baris berstatus error yang memerlukan verifikasi.
- `metadata/`: kamus data, hasil aturan, daftar isu, profil tabel, sumber, manifest, dan log transformasi.
- `quality_report.xlsx`: laporan audit yang dapat difilter di Excel.

## Cara memakai data bersih

Setiap tabel bersih memiliki:

- `dq_status`: `valid`, `corrected`, `warning`, atau `error`.
- `dq_issue_codes`: daftar aturan kualitas yang berlaku pada baris.

Untuk analisis dengan aturan paling ketat, gunakan baris dengan `dq_status` bernilai `valid` atau `corrected`. Baris `warning` tetap dipertahankan karena masih dapat digunakan dengan pertimbangan bisnis. Baris `error` dipertahankan pada tabel bersih agar relasi antar tabel tidak terputus, dan salinannya tersedia di `quarantine/`.

## Perubahan utama

- 261.831 duplikat persis geolokasi tidak digunakan ulang.
- Geolokasi dikanonisasi menjadi 19.015 prefix kode pos.
- Kode pos, kota, provinsi, timestamp, dan nama kategori distandardisasi.
- 610 kategori produk kosong dipetakan ke sentinel `unknown` dan tetap ditandai.
- Dua cicilan kartu kredit bernilai nol diubah menjadi satu.
- Tiga tipe pembayaran `not_defined` diubah menjadi `unknown`.
- `review_key` komposit ditambahkan untuk 1.603 baris yang memakai `review_id` bersama pesanan berbeda.
- 49 baris order dan 5 prefix geolokasi berstatus error; salinannya tersedia di karantina.

## Batasan

Akurasi terhadap alamat, identitas, dan koordinat di dunia nyata tidak dapat dipastikan tanpa sumber referensi eksternal. Karena itu, kasus yang tidak aman diperbaiki otomatis ditandai atau dikarantina dan tidak diganti dengan nilai rekaan.
