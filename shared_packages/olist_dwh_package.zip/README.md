# Olist Data Warehouse

Data warehouse ini dibangun dari CSV berkualitas pada `olist_data_quality_final/clean` dengan metode full refresh.

## Model

- `dim_date`: kalender untuk seluruh tanggal transaksi.
- `dim_geolocation`: satu anggota per prefix kode pos kanonis.
- `dim_customer`: grain satu `customer_id`; `customer_unique_id` tetap tersedia untuk analisis pelanggan lintas pesanan.
- `dim_seller`: grain satu penjual.
- `dim_product`: grain satu produk, termasuk kategori Portugis dan terjemahan Inggris.
- `fact_order`: grain satu pesanan.
- `fact_sales`: grain satu item dalam pesanan.
- `fact_payment`: grain satu urutan pembayaran dalam pesanan.
- `fact_review`: grain satu `review_key` komposit.

Fakta pembayaran dan ulasan sengaja dipisahkan dari item penjualan. Jangan menggabungkan ketiganya langsung tanpa agregasi per pesanan karena dapat menggandakan nilai. Gunakan `vw_order_summary` untuk analisis gabungan yang aman.

## Kebijakan kualitas

Secara default, baris `dq_status=error` tidak dimuat ke fakta/dimensi utama. Baris tersebut dan baris anak yang kehilangan parent dicatat di `etl_reject`. Baris `valid`, `corrected`, dan `warning` tetap dimuat beserta `dq_status` dan `dq_issue_codes`.

## Menjalankan ulang

```powershell
python D:\Pangdat\scripts\build_olist_dwh.py
```

Gunakan `--include-errors` hanya bila analisis memerlukan seluruh baris sumber dan konsekuensi kualitasnya telah diterima.

## Hasil muat

- `dim_date`: 756 baris
- `dim_geolocation`: 19,011 baris
- `dim_customer`: 99,442 baris
- `dim_seller`: 3,096 baris
- `dim_product`: 32,952 baris
- `fact_order`: 99,392 baris
- `fact_sales`: 112,576 baris
- `fact_payment`: 103,834 baris
- `fact_review`: 99,175 baris

Validasi: 26 PASS dan 0 FAIL.
